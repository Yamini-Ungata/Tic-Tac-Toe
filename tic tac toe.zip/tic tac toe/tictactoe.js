let btns=document.querySelectorAll(".btn");
let rst=document.querySelector("#reset");
let newmsg=document.querySelector(".msg-container");
let msg=document.querySelector("#msg");
let neww=document.querySelector("#new");

let X=true;
const win=[
    [0,1,2],
    [0,3,6],
    [0,4,8],
    [3,4,5],
    [1,4,7],
    [2,5,8],
    [2,4,6],
    [6,7,8]];
btns.forEach((btn)=>{
    btn.addEventListener("click",()=>
    {
        if(X){
        btn.innerText="X";
        X=false;
        }
        else{
            btn.innerText="O";
            X=true;
        }
        btn.disabled=true;
        check();
    });
    
});
rst.addEventListener("click",()=>{
    btns.forEach((btn)=>{
        btn.innerText="";
        btn.disabled=false;
        X=true;
    });

});
neww.addEventListener("click",()=>{
    btns.forEach((btn)=>{
        btn.innerText="";
        btn.disabled=false;
        X=true;
    });
    newmsg.classList.add("hide");
});

const showWinner=(winner)=>{
    msg.innerText=`Congratulations, winner is ${winner}`;
    newmsg.classList.remove("hide");
}
const check=()=>{
    for(let pattern of win){
        let pos1= btns[pattern[0]].innerText;
        let pos2= btns[pattern[1]].innerText;
        let pos3=btns[pattern[2]].innerText;
        if(pos1!="" && pos2!="" &&  pos3!="")
        if(pos1===pos2 && pos2===pos3){
            showWinner(pos1);
        }

        
    }
}
neww.addEventListener("click",()=>{
    btns.forEach((btn)=>{
        btn.innerText="";
        X=true;
    });

});